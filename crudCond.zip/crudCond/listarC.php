<?php
require_once "ConductorService.php";

$service = new ConductorService();
$service->listarConductores();
?>